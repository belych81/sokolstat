<?php

namespace Negotiation\Exception;

class InvalidArgument extends \InvalidArgumentException implements Exception
{
}
