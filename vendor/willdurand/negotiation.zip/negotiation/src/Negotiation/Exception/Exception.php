<?php

namespace Negotiation\Exception;

interface Exception
{
}
